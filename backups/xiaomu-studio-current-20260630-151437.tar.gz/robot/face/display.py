"""Display backends — push a rendered PIL face to the robot's screen, or a file.

The face is designed at 320x200; the XGO LCD is 320x240, so faces are centered
onto the panel with fit_to_panel(). LcdDisplay is the real device (Pi only);
FileDisplay is for development on any machine.

LcdDisplay also (a) turns the LCD backlight ON — the xgoscreen lib leaves GPIO 0
(BL) low, and only the (now-disabled) Yahboom demo used to drive it high — and
(b) overlays a 4-corner button legend so the operator can see what each key does.
"""
from __future__ import annotations

import os

from PIL import Image, ImageDraw, ImageFont

LCD_W, LCD_H = 320, 240
FACE_Y = 20  # vertical offset to center the 320x200 face on the 320x240 panel
PANEL_BG = (0x1A, 0x14, 0x20)

CJK_FONT = os.environ.get("XIAOMU_CJK_FONT", "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf")
SHOW_LABELS = os.environ.get("XIAOMU_SHOW_LABELS", "1") != "0"

# (corner, label) — matches the physical corner buttons (TL=start, TR=talk,
# BL=next, BR=repeat); GPIO mapping is in hw/buttons.py PIN_MAP.
BUTTON_LABELS = [
    ("tl", "开始/停止"),
    ("tr", "按住说话"),
    ("bl", "下一个"),
    ("br", "重复"),
]

_legend_cache = None


def _build_legend():
    """A cached 320x240 RGBA overlay with the 4 button labels in the corners."""
    global _legend_cache
    if _legend_cache is not None:
        return _legend_cache
    overlay = Image.new("RGBA", (LCD_W, LCD_H), (0, 0, 0, 0))
    try:
        font = ImageFont.truetype(CJK_FONT, 15)
    except Exception:
        _legend_cache = overlay
        return overlay
    d = ImageDraw.Draw(overlay)
    pad = 3
    for corner, text in BUTTON_LABELS:
        bbox = d.textbbox((0, 0), text, font=font)
        tw, th = bbox[2] - bbox[0], bbox[3] - bbox[1]
        if corner == "tl":
            x, y = pad, 1
        elif corner == "tr":
            x, y = LCD_W - tw - pad, 1
        elif corner == "bl":
            x, y = pad, LCD_H - th - 5
        else:  # br
            x, y = LCD_W - tw - pad, LCD_H - th - 5
        d.rectangle((x - 2, y - 1, x + tw + 2, y + th + 3), fill=(0, 0, 0, 130))
        d.text((x, y), text, font=font, fill=(170, 170, 185, 235))
    _legend_cache = overlay
    return overlay


def fit_to_panel(face: Image.Image) -> Image.Image:
    """Center a 320x200 face onto the 320x240 LCD panel (no-op if already sized)."""
    if face.size == (LCD_W, LCD_H):
        return face
    canvas = Image.new("RGB", (LCD_W, LCD_H), PANEL_BG)
    x = (LCD_W - face.width) // 2
    canvas.paste(face, (x, FACE_Y))
    return canvas


class Display:
    size = (LCD_W, LCD_H)

    def show(self, img: Image.Image) -> None:
        raise NotImplementedError

    def clear(self) -> None:
        pass


class LcdDisplay(Display):
    """XGO 2-inch SPI LCD via xgoscreen (imports only work on the Pi)."""

    def __init__(self) -> None:
        import xgoscreen.LCD_2inch as LCD_2inch  # noqa: WPS433 (device-only import)
        self._d = LCD_2inch.LCD_2inch()
        # CRITICAL: LCD_2inch.__init__ does NOT run the ST7789 reset+init — only
        # Init() does (and only its reset arm when /tmp/screen_initialized is
        # absent, i.e. after a reboot). The Yahboom demo used to call it; with the
        # demo gone, WE must, or the panel is never initialized → black screen.
        self._d.Init()
        self._d.clear()
        os.system("pinctrl set 0 op dh")  # belt-and-suspenders backlight high

    def show(self, img: Image.Image) -> None:
        panel = fit_to_panel(img)
        if SHOW_LABELS:
            legend = _build_legend()
            panel.paste(legend, (0, 0), legend)  # alpha-composite the labels
        self._d.ShowImage(panel)

    def clear(self) -> None:
        self._d.clear()


class FileDisplay(Display):
    """Dev backend: overwrite a PNG with the latest frame (open it to watch)."""

    def __init__(self, path: str = "preview/_live.png") -> None:
        self.path = path

    def show(self, img: Image.Image) -> None:
        panel = fit_to_panel(img)
        if SHOW_LABELS:
            legend = _build_legend()
            panel.paste(legend, (0, 0), legend)
        panel.save(self.path)
